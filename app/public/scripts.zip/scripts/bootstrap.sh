#!/usr/bin/env bash

ROOT=$(pwd)

while (("$#")); do
  case "$1" in
  -a | --action)
    ACT=$2
    shift 2
    ;;
  --) # end argument parsing
    shift
    break
    ;;
  -* | --*=) # unsupported flags
    echo "Error: Unsupported flag $1" >&2
    exit 1
    ;;
  *) # preserve positional arguments
    PARAMS="$PARAMS $1"
    shift
    ;;
  esac
done
# set positional arguments in their proper place
eval set -- "$PARAMS"

if [ -z "$ACT" ]; then
  ACT="up"
fi

if [ "$(docker ps -a --format "{{.Names}}" --filter name=merge_app* --filter "status=exited" | wc -l)" -ne "4" ]; then
  . ./scripts/server.sh
fi

echo -e "\e[92mSolely for fulfilling dependencies of the project\e[0m"

echo -e "\e[33mComposer Install\e[0m"
docker-compose exec php [ ! -d "vendor/" ] && docker-compose exec php composer install

if [[ "$ACT" == "reset" ]]; then
  docker-compose exec php php artisan migrate:refresh
fi
