#!/usr/bin/env bash

echo -e "\e[92mSetup\e[0m"
if [ ! -f ./.env ]; then
  . ./scripts/setup.sh
fi

echo -e "\e[92mStart the application\e[0m"

if [ ! "$(docker ps -a --format "{{.Names}}" --filter name=merge_app*)" ]; then
  echo -e "\e[33mdocker-compose build\e[0m"
  docker-compose build
  docker-compose run php composer install
  docker-compose run php npm install
  docker-compose run php php artisan key:generate
  docker-compose exec php php artisan migrate:refresh --seed
  docker-compose exec php php artisan passport:install
  docker-compose exec php php artisan l5-swagger:generate
fi

echo -e "\e[33mdocker-compose up -d\e[0m"
docker-compose up -d
