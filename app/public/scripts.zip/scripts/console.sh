#!/usr/bin/env bash

docker-compose exec php "$@"
