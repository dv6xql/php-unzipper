#!/usr/bin/env bash

echo -e "\e[92mSet up a project in an initial state\e[0m"

ROOT=$(pwd)

while (("$#")); do
  case "$1" in
  -e | --environment)
    ENV=$2
    shift 2
    ;;
  --) # end argument parsing
    shift
    break
    ;;
  -* | --*=) # unsupported flags
    echo "Error: Unsupported flag $1" >&2
    exit 1
    ;;
  *) # preserve positional arguments
    PARAMS="$PARAMS $1"
    shift
    ;;
  esac
done
# set positional arguments in their proper place
eval set -- "$PARAMS"

if [ -z "$ENV" ]; then
  ENV="local"
fi

echo -e "\e[33mClean files and folders\e[0m"
[ -f ./.env ] && rm ./.env
[ -f ./app/.env ] && rm ./app/.env
[ -f ./app/composer.lock ] && rm ./app/composer.lock
[ -f ./app/package-lock.json ] && rm ./app/package-lock.json

[ -d ./app/vendor ] && rm -rf ./app/vendor
[ -d ./app/node_modules ] && rm -rf ./app/node_modules
[ -d ./app/var ] && rm -rf ./app/var

echo -e "\e[33mStop Cotainers\e[0m"
if [[ $(docker container ls -q --filter name=merge_app*) ]]; then
  docker stop $(docker container ls -q --filter name=merge_app*)
fi

echo -e "\e[33mRemove images\e[0m"
if [[ $(docker container ls -q --filter name=merge_app*) ]]; then
  docker rmi $(docker container ls -q --filter name=merge_app*)
fi

echo -e "\e[33mDelete Containeres\e[0m"
if [[ $(docker ps -a -f status=exited -q --filter name=merge_app*) ]]; then
  docker rm $(docker ps -a -f status=exited -q --filter name=merge_app*)
fi

echo -e "\e[33mRemove all unused images not just dangling ones\e[0m"
docker system prune -a -f

echo -e "\e[33mRemove all unused local volumes\e[0m"
docker volume prune -f

if [ "$ENV" == "local" ]; then
  APP_NAME=MergeApp
  APP_ENV=local
  APP_KEY=base64:kCR8yph19JRaKKZII8A4rIr63ev2v35AYY2xrsJm+TE=
  APP_DEBUG=true
  APP_URL=http://localhost:8000

  DB_CONNECTION=mysql
  DB_HOST=mysql
  DB_PORT=3306
  DB_DATABASE=mergeapp_one
  DB_USERNAME=root
  DB_PASSWORD=root

  MAIL_MAILER=smtp
  MAIL_HOST=smtp.mailtrap.io
  MAIL_PORT=2525
  MAIL_USERNAME=817f8a9af4b5ae
  MAIL_PASSWORD=e33090b6a2c658
  MAIL_ENCRYPTION=tls
  MAIL_FROM_ADDRESS="noreply@mergeapp.one"
  MAIL_FROM_NAME="MergeApp"

  SENTRY_LARAVEL_DSN=""
  SENTRY_TRACES_SAMPLE_RATE=""
elif [ "$ENV" == "prod" ]; then
  APP_NAME=MergeApp
  APP_ENV=production
  APP_KEY=base64:kCR8yph19JRaKKZII8A4rIr63ev2v35AYY2xrsJm+TE=
  APP_DEBUG=false
  APP_URL=https://www.mergeapp.one/api

  DB_CONNECTION=mysql
  DB_HOST=mergeapp.one.mysql
  DB_PORT=3306
  DB_DATABASE=mergeapp_one
  DB_USERNAME=mergeapp_one
  DB_PASSWORD=stor6666

  MAIL_MAILER=smtp
  MAIL_HOST=mailout.one.com
  MAIL_PORT=587
  MAIL_USERNAME=noreply@mergeapp.one
  MAIL_PASSWORD=stor6666
  MAIL_ENCRYPTION=tls
  MAIL_FROM_ADDRESS=noreply@mergeapp.one
  MAIL_FROM_NAME="MergeApp"

  SENTRY_LARAVEL_DSN=https://47e99c74c4b84f28a37830cc00a66bdc@o460917.ingest.sentry.io/5461935
  SENTRY_TRACES_SAMPLE_RATE=1
fi

echo -e "\e[33mCreating .env\e[0m"
cat <<E_O_ENV >./.env
DOCKER_APP_NAME=merge_app
NGINX_PORT=8088

MYSQL_PORT=33066
MYSQL_DATABASE=mergeapp_one
MYSQL_PASSWORD=root
MYSQL_ROOT_PASSWORD=root

PHP_PORT=8000
PHPMYADMIN_PORT=8001
E_O_ENV

echo -e "\e[33mCreating ./app/.env\e[0m"
cat <<E_O_ENV >./app/.env
APP_VERSION=0.4.1
APP_NAME=$APP_NAME
APP_DESCRIPTION="MergeApp profiles your social media contacts and reveal their true value to you."
APP_ENV=$APP_ENV
APP_KEY=$APP_KEY
APP_DEBUG=$APP_DEBUG
APP_URL=$APP_URL

DB_CONNECTION=$DB_CONNECTION
DB_HOST=$DB_HOST
DB_PORT=$DB_PORT
DB_DATABASE=$DB_DATABASE
DB_USERNAME=$DB_USERNAME
DB_PASSWORD=$DB_PASSWORD

LOG_CHANNEL=stack

BROADCAST_DRIVER=log
CACHE_DRIVER=file
QUEUE_CONNECTION=sync
SESSION_DRIVER=file
SESSION_LIFETIME=120

REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379

MAIL_MAILER=${MAIL_MAILER}
MAIL_HOST=${MAIL_HOST}
MAIL_PORT=${MAIL_PORT}
MAIL_USERNAME=${MAIL_USERNAME}
MAIL_PASSWORD=${MAIL_PASSWORD}
MAIL_ENCRYPTION=${MAIL_ENCRYPTION}
MAIL_FROM_ADDRESS=${MAIL_FROM_ADDRESS}
MAIL_FROM_NAME=${MAIL_FROM_NAME}

AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_DEFAULT_REGION=us-east-1
AWS_BUCKET=

PUSHER_APP_ID=
PUSHER_APP_KEY=
PUSHER_APP_SECRET=
PUSHER_APP_CLUSTER=mt1

MIX_PUSHER_APP_KEY="${PUSHER_APP_KEY}"
MIX_PUSHER_APP_CLUSTER="${PUSHER_APP_CLUSTER}"

SENTRY_LARAVEL_DSN="${SENTRY_LARAVEL_DSN}"
SENTRY_TRACES_SAMPLE_RATE="${SENTRY_TRACES_SAMPLE_RATE}"
E_O_ENV
